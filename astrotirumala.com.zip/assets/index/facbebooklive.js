var iframe = document.createElement('.fb-page');
src = 'https://www.facebook.com/srisaibalajiastrocentrebangalore';
loading = 'lazy';
document.body.appendChild(iframe);